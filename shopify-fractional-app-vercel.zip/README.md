# Vercel-ready Next.js Shopify Fractional App

Follow the step-by-step instructions inside the chat to deploy this app on Vercel.